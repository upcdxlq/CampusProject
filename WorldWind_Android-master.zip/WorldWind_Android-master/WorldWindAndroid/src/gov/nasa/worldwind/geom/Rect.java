/*
 * Copyright (C) 2012 United States Government as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 */
package gov.nasa.worldwind.geom;

import gov.nasa.worldwind.util.Logging;

/**
 * @author dcollins
 * @version $Id: Rect.java 733 2012-09-02 17:15:09Z dcollins $
 */
public class Rect
{
    public double x;
    public double y;
    public double width;
    public double height;

    public Rect()
    {
    }

    public Rect(double x, double y, double width, double height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public Rect copy()
    {
        return new Rect(this.x, this.y, this.width, this.height);
    }

    public Rect set(Rect rect)
    {
        if (rect == null)
        {
            String msg = Logging.getMessage("nullValue.RectIsNull");
            Logging.error(msg);
            throw new IllegalArgumentException(msg);
        }

        this.x = rect.x;
        this.y = rect.y;
        this.width = rect.width;
        this.height = rect.height;

        return this;
    }

    public Rect set(double x, double y, double width, double height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        return this;
    }
}
