/*
 * Copyright (C) 2012 United States Government as represented by the Administrator of the
 * National Aeronautics and Space Administration.
 * All Rights Reserved.
 */
package gov.nasa.worldwind;

import gov.nasa.worldwind.avlist.AVListImpl;
import gov.nasa.worldwind.event.Message;
import gov.nasa.worldwind.util.Logging;

import java.beans.PropertyChangeEvent;

/**
 * Implements <code>WWObject</code> functionality. Meant to be either subclassed or aggregated by classes implementing
 * <code>WWObject</code>.
 *
 * @author dcollins
 * @version $Id: WWObjectImpl.java 771 2012-09-14 19:30:10Z tgaskins $
 */
public class WWObjectImpl extends AVListImpl implements WWObject
{
    /** Constructs a new <code>WWObjectImpl</code>. */
    public WWObjectImpl()
    {
    }

    public WWObjectImpl(Object source)
    {
        super(source);
    }

    /**
     * The property change listener for <em>this</em> instance. Receives property change notifications that this
     * instance has registered with other property change notifiers.
     *
     * @param event the property change event.
     *
     * @throws IllegalArgumentException if <code>propertyChangeEvent</code> is null
     */
    public void propertyChange(PropertyChangeEvent event)
    {
        if (event == null)
        {
            String msg = Logging.getMessage("nullValue.EventIsNull");
            Logging.error(msg);
            throw new IllegalArgumentException(msg);
        }

        // Notify all *my* listeners of the change that I caught
        super.firePropertyChange(event);
    }

    /** Empty implementation of MessageListener. */
    public void onMessage(Message message)
    {
        // Empty implementation
    }
}
