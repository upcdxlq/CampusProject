class CWebViewModule : public CAtlDllModuleT< CWebViewModule >
{
};

extern class CWebViewModule _AtlModule;
