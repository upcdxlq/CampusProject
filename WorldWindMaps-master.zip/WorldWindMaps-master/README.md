# WorldWindMaps  
An application adds several maps into worldwind demo  


## 2017-5-19  
### Tianditu Mercator  
1. Tianditu Vector Map (Mercator)  
2. Tianditu Satellite Image (Mercator)  
3. Tianditu Boundary (Mercator)  
4. Tianditu Vector Chinese Label (Mercator)  
5. Tianditu Vector English Label (Mercator)  
6. Tianditu Satellite Chineses Label (Mercator)  
7. Tianditu Satellite English Label (Mercator)  
            
### Tianditu Non-Mercator  
1. Tianditu Vector Map  
2. Tianditu Satellite Image  
3. Tianditu Boundary  
4. Tianditu Vector Chinese Label  
5. Tianditu Vector English label  
6. Tianditu Satellite Chinese Label  
7. Tianditu Satellite English Label  


### Esri Mercator  
1. Esri World Street Map  
2. Esri World Imagery  
3. Esri World Transportation  

## 2017-5-21  
### Tencent Mercator  
1. Tencent Map  
2. Tencent Satellite (NG)  
3. Tencent Label  

### Google CN Mercator  
1. Google Map  
2. Google Terrain
3. Google Terrain with Label
4. Google Satellite 
5. Google Satellite with Label
6. Google Label


            
